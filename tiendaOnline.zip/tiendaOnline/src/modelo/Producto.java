package modelo;

public class Producto {
	
	private String titulo;
	private double precio;
	private String autor;
	private String genero;
	private int pags;
	private int id;
	private int idCategoriaProducto;
	
	private CategoriaProducto categoriaProducto;
	
	public Producto() {
		
	}
	
	public Producto(String titulo, double precio, String autor, String genero,
			int pags) {
		super();
		this.titulo = titulo;
		this.precio = precio;
		this.autor = autor;
		this.genero = genero;
		this.pags = pags;
	}

	public final String getTitulo() {
		return titulo;
	}
	public final void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public final double getPrecio() {
		return precio;
	}
	public final void setPrecio(double precio) {
		this.precio = precio;
	}
	public final String getAutor() {
		return autor;
	}
	public final void setAutor(String autor) {
		this.autor = autor;
	}
	public final String getGenero() {
		return genero;
	}
	public final void setGenero(String genero) {
		this.genero = genero;
	}
	public final int getPags() {
		return pags;
	}
	public final void setPags(int pags) {
		this.pags = pags;
	}
	public final int getId() {
		return id;
	}
	public final void setId(int id) {
		this.id = id;
	}
	
	public int getIdCategoriaProducto() {
		return idCategoriaProducto;
	}

	public void setIdCategoriaProducto(int idCategoriaProducto) {
		this.idCategoriaProducto = idCategoriaProducto;
	}

	public CategoriaProducto getCategoriaProducto() {
		return categoriaProducto;
	}

	public void setCategoriaProducto(CategoriaProducto categoriaProducto) {
		this.categoriaProducto = categoriaProducto;
	}

	@Override
	public String toString() {
		return "Producto [titulo=" + titulo + ", precio=" + precio + ", autor="
				+ autor + ", genero=" + genero + ", pags=" + pags + ", id="
				+ id + "]";
	}

}
