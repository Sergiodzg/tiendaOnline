package modelo;

public class Servicio {
	
	private String nombre;
	private String descripcion;
	private double precio;
	
	public Servicio() {
		// TODO Auto-generated constructor stub
	}
	
	public Servicio(String nombre, String descripcion, double precio) {
		super();
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public final String getNombre() {
		return nombre;
	}

	public final void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public final String getDescripcion() {
		return descripcion;
	}

	public final void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public final double getPrecio() {
		return precio;
	}

	public final void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Servicio [nombre=" + nombre + ", descripcion=" + descripcion
				+ ", precio=" + precio + "]";
	}
		

}
