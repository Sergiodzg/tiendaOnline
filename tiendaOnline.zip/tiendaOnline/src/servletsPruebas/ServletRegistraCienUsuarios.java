package servletsPruebas;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;


@WebServlet("/ServletRegistraCienUsuarios")
public class ServletRegistraCienUsuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//servlet que pide el dao de usuarios a spring para registrar 100 usuarios
		//y asi poder hacer pruebas con el tema de paginacion
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
		for (int i = 0; i < 10; i++) {
			Usuario u = new Usuario("luis" + i, i + "l@gmail.com", "1234");
			dao.registrarUsuario(u);
			System.out.println("registrado: " + u.toString());
		}//end for
		System.out.println("100 usuarios registrados");
	}//end service

}
