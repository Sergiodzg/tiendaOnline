package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;



@WebServlet("/ServletListadoProductosPortada")
public class ServletListadoProductosPortada extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//ahora hacemos lo mismo que cuando hemos listado usuarios
		//debemos pedir el dao al contenedor de spring y mandarle los productosa listadoProductos.jsp
		//para que los muestre
		
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
	
		//parte de busqueda:
			String campoBusqueda = request.getParameter("campoBusqueda");
			if (campoBusqueda == null) {
			campoBusqueda = "";
					
			}
			System.out.println("buscar producto con titulo "+ campoBusqueda);
			request.setAttribute("campoBusqueda", campoBusqueda);
						
		//parte de paginacion:
		
		
		
		int comienzo = 0;
		int cuantos = 3;
		
		if(request.getParameter("comienzo")!=null){
			comienzo = Integer.parseInt(request.getParameter("comienzo"));
		}
		
		int siguiente = comienzo + 3;
		int anterior = comienzo - 3;
		int total = dao.obtenerTotalProductos(campoBusqueda);
		
		
		List<Producto> productos = dao.obtenerProducto(comienzo, cuantos, campoBusqueda);
		
		request.setAttribute("productos", productos);
		request.setAttribute("anterior", anterior);
		request.setAttribute("siguiente", siguiente);
		request.setAttribute("total", total);
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/portada.jsp");
		rd.forward(request, response);
		
	}

}
