package servlets.admin;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import daos.ProductosDAOImpl;
import modelo.Producto;


@WebServlet("/admin/ServletRegistroProductoAdmin")
@MultipartConfig
public class ServletRegistroProductoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String titulo = request.getParameter("campoTitulo");
		String precio = request.getParameter("campoPrecio");
		String autor = request.getParameter("campoAutor");
		String genero = request.getParameter("campoGenero");
		String pags = request.getParameter("campoPags");
		String idCategoria = request.getParameter("campoIdCategoria");
		precio = precio.replace(",", ".");
		double precioDouble = Double.parseDouble(precio);
		int pagsInt = Integer.parseInt(pags);
		
		
		//ahora hay que pedir al contenedor de spring para registrar el nuevo producto
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		
		Producto nuevo = new Producto(titulo, precioDouble, autor, genero, pagsInt);
		nuevo.setIdCategoriaProducto(Integer.parseInt(idCategoria));
		
		System.out.println("Voy a registrar: " + nuevo);
		System.out.println("vamos a ver si somos capaces de recuperar una bean del contenedor de Spring");
		
		int idGenerado = dao.registrarProducto(nuevo);
		
		//procesar la subida de archivo
		
		String rutaArchivo = getServletContext().getRealPath("") + "/" + "subidasImagenesProductos";
		File carpeta = new File(rutaArchivo);
		
		if( ! carpeta.exists()){
			carpeta.mkdir();
		}
		Part campoImagen = request.getPart("campoImagen");
		campoImagen.write(rutaArchivo + "/" + idGenerado + ".jpg");
		
		System.out.println("archivo subido a la carpeta: " + rutaArchivo);
		
		
		//una vez registrado el producto mostramos el listado de producto
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin/ServletListadoProductos");
		rd.forward(request, response);
		
			
	}

}
