package servlets.admin;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;


@WebServlet("/admin/ServletRegistroUsuarioAdmin")
@MultipartConfig
public class ServletRegistroUsuarioAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre = request.getParameter("campoNombre");
		String email = request.getParameter("campoEmail");
		String pass = request. getParameter("campoPass");
		String idCategoria = request.getParameter("campoIdCategoria");
		
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
		int id = dao.obtenerUsuarioPorEmail(email);

		if (id > 0) {
			System.out.println("el email ya existe");
			request.setAttribute("errorRegistro", "  El email ya existe. Por favor introduce otro.");
			RequestDispatcher rd = getServletContext().getRequestDispatcher(
					"/admin/registroUsuario.jsp");
			rd.forward(request, response);
		} else {

			Usuario nuevo = new Usuario(nombre, email, pass);
			nuevo.setIdCategoriaUsuario(Integer.parseInt(idCategoria));
			
			System.out.println("Voy a registrar: " + nuevo);
			System.out.println("vamos a ver si somos capaces de recuperar una bean del contenedor de Spring");

			int idGenerado = dao.registrarUsuario(nuevo);
			
			// procesar la subida de archivo

			String rutaArchivo = getServletContext().getRealPath("") + "/"+ "subidasImagenesUsuarios";
			File carpeta = new File(rutaArchivo);

			if (!carpeta.exists()) {
				carpeta.mkdir();
			}
			Part campoImagen = request.getPart("campoImagen");
			campoImagen.write(rutaArchivo + "/" + idGenerado + ".jpg");

			System.out.println("archivo subido a la carpeta: " + rutaArchivo);
		
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin/ServletListadoUsuarios");
			rd.forward(request, response);
			
		}
	}
}
