package constantes;

public class ConstanteSQL {
	
	
	public final static String SQL_SELECCION_ID_POR_EMAIL_PASS = "select id from tabla_usuarios where email = ? and pass = ?";
	
	public final static String SQL_SELECCION_ID_POR_EMAIL = "select id from tabla_usuarios where email = ?";

	public final static String SQL_SELECCION_USUARIOS = "select * from tabla_usuarios order by id desc";
	
	public final static String SQL_BORRAR_USUARIO = "delete from tabla_usuarios where id = ?";
	
	public final static String SQL_OBTENER_USUARIO_POR_ID = "select * from tabla_usuarios where id = ?";
	
	public final static String SQL_ACTUALIZAR_USUARIO = "update tabla_usuarios set nombre = ? , email = ?, pass = ? where id = ?";
	
	public final static String SQL_SELECCION_USUARIOS_INICIO_CUANTOS = "SELECT * FROM bd_tienda.tabla_usuarios order by id desc limit ?,?";
	
	public final static String SQL_TOTAL_USUARIOS = "select count(*) from tabla_usuarios";
	
	public final static String SQL_SELECCION_USUARIOS_CUANTOS_BUSQUEDA = "SELECT tu.id,tu.nombre,tu.email,tu.pass,tcu.nombre as nombre_categoria FROM tabla_usuarios as tu, tabla_categorias_usuario as tcu where tu.idCategoriaUsuario = tcu.id and tu.nombre like ? order by tu.id desc limit ?,?";
	
	public final static String SQL_TOTAL_USUARIOS_BUSQUEDA = "select count(*) from tabla_usuarios  where nombre like ?";
	
	public final static String SQL_SELECCION_USUARIOS_CATEGORIAS = "select * from tabla_categorias_usuario order by id desc";
	
	
	
	
	public final static String SQL_SELECCION_PRODUCTOS = "select * from tabla_productos order by id desc";
	
	public final static String SQL_BORRAR_PRODUCTO = "delete from tabla_productos where id = ?";
	
	public final static String SQL_OBTENER_PRODUCTO_POR_ID = "select * from tabla_productos where id = ?";
	
	public final static String SQL_ACTUALIZAR_PRODUCTO = "update tabla_productos set titulo = ? , precio = ?, autor = ?, genero = ?, pags = ? where id = ?";
	
	public final static String SQL_SELECCION_PRODUCTOS_INICIO_CUANTOS = "SELECT * FROM bd_tienda.tabla_productos order by id desc limit ?,?";
	
	public final static String SQL_TOTAL_PRODUCTOS = "select count(*) from tabla_productos";
	
	public final static String SQL_SELECCION_PRODUCTOS_CUANTOS_BUSQUEDA = "SELECT tp.id,tp.titulo,tp.precio,tp.autor,tp.genero,tp.pags,tcp.nombre as nombre_categoria FROM tabla_productos as tp, tabla_categorias_producto as tcp where tp.idCategoriaProducto = tcp.id and tp.titulo like ? order by tp.id desc limit ?,?";
	
	public final static String SQL_TOTAL_PRODUCTOS_BUSQUEDA = "select count(*) from tabla_productos  where titulo like ?";
	
	public final static String SQL_SELECCION_PRODUCTOS_CATEGORIAS = "select * from tabla_categorias_producto order by id desc";
	
	
	
	
	public final static String SQL_SELECCION_SERVICIOS =
			"select * from tabla_servicios order by id desc";
	
	
	
	public final static String SQL_SELECCION_CATEGORIAS =
			"select * from tabla_categorias order by id desc";
	
}
