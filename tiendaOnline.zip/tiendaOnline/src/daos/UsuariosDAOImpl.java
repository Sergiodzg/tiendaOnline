package daos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstanteSQL;
import mappers.UsuariosMapper;
import modelo.Usuario;

public class UsuariosDAOImpl implements UsuariosDAO {

	private DataSource elDataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;

	public void setElDataSource(DataSource elDataSource) {
		this.elDataSource = elDataSource;
		simpleInsert = new SimpleJdbcInsert(elDataSource);
		simpleInsert.setTableName("tabla_usuarios");
		simpleInsert.usingGeneratedKeyColumns("id");
		jdbcTemplate = new JdbcTemplate(elDataSource);
	}

	@Override
	public int registrarUsuario(Usuario u) {
		//no solo necesitamos insertar sino ademas saber que numero de id seha generado
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", u.getNombre());
		valores.put("email", u.getEmail());
		valores.put("pass", u.getPass());
		valores.put("idCategoriaUsuario", u.getIdCategoriaUsuario());
//		simpleInsert.execute(valores);
		int idGenerate = simpleInsert.executeAndReturnKey(valores).intValue();
		return idGenerate;
	}

	@Override
	public ArrayList<Usuario> obtenerUsuarios() {
		String sql = ConstanteSQL.SQL_SELECCION_USUARIOS;
		ArrayList<Usuario> usuarios = (ArrayList<Usuario>) jdbcTemplate.query(sql, new BeanPropertyRowMapper(Usuario.class));
		return usuarios;
	}

	public DataSource getElDataSource() {
		return elDataSource;
	}

	public SimpleJdbcInsert getSimpleInsert() {
		return simpleInsert;
	}

	public void setSimpleInsert(SimpleJdbcInsert simpleInsert) {
		this.simpleInsert = simpleInsert;
	}

	@Override
	public int obtenerUsuarioPorEmailYPass(String email, String pass) {

		int id = -1;

		String sql = ConstanteSQL.SQL_SELECCION_ID_POR_EMAIL_PASS;
		String[] valores = { email, pass };

		try {
			id = jdbcTemplate.queryForInt(sql, valores);
		} catch (Exception e) {
			System.out.println("error al obtener el id del usuario");
			System.out.println();
		}

		return id;
	}

	@Override
	public void borrarUsuarioPorId(int id) {
		jdbcTemplate.update(ConstanteSQL.SQL_BORRAR_USUARIO,id);
	}

	@Override
	public Usuario obtenerUsuarioPorId(int id) {
		String valores[] = {String.valueOf(id)};
		Usuario usuario = (Usuario) jdbcTemplate.queryForObject(ConstanteSQL.SQL_OBTENER_USUARIO_POR_ID,valores,new BeanPropertyRowMapper(Usuario.class));
		return usuario;
	}

	@Override
	public void actualizarUsuario(Usuario u) {

		jdbcTemplate.update(ConstanteSQL.SQL_ACTUALIZAR_USUARIO,u.getNombre(),u.getEmail(),u.getPass(),u.getId());
		
	}

	@Override
	public List<Usuario> obtenerUsuarios(int comienzo, int cuantos) {
		Integer[] valores = {Integer.valueOf(comienzo),Integer.valueOf(cuantos)};
		List<Usuario> usuarios = jdbcTemplate.query(ConstanteSQL.SQL_SELECCION_USUARIOS_INICIO_CUANTOS,valores,new BeanPropertyRowMapper(Usuario.class));
		return usuarios;
		
	}

	@Override
	public int obtenerTotalUsuarios() {
		int total = jdbcTemplate.queryForInt(ConstanteSQL.SQL_TOTAL_USUARIOS);
		return total;
	}

	@Override
	public int obtenerUsuarioPorEmail(String email) {
		
		int id = -1;

		String sql = ConstanteSQL.SQL_SELECCION_ID_POR_EMAIL;
		String[] valores = {email};

		try {
			id = jdbcTemplate.queryForInt(sql, valores);
		} catch (Exception e) {
			System.out.println("error al obtener el id del usuario");
			System.out.println();
		}

		return id;
		
	}

	@Override
	public List<Usuario> obtenerUsuarios(int comienzo, int cuantos,
			String busqueda) {
		Object[] valores = {"%"+busqueda+"%", Integer.valueOf(comienzo),Integer.valueOf(cuantos)};

		List<Usuario> usuarios = jdbcTemplate.query(ConstanteSQL.SQL_SELECCION_USUARIOS_CUANTOS_BUSQUEDA,valores,new UsuariosMapper());
		
		//usuariosMapper es un clase donde vamos a decir como formar un usuario de cada fila resultado de la base de datos
		
		return usuarios;
	}

	@Override
	public int obtenerTotalUsuarios(String busqueda) {
		int total = jdbcTemplate.queryForInt(ConstanteSQL.SQL_TOTAL_USUARIOS_BUSQUEDA,"%"+busqueda+"%");
		return total;
	}

}
