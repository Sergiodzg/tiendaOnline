package daos;

import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstanteSQL;

import modelo.Servicio;

public class ServiciosDAOImpl implements ServiciosDAO{
	
	private DataSource elDataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;

	@Override
	public void registrarServicio(Servicio s) {
		
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", s.getNombre());
		valores.put("descripcion", s.getDescripcion());
		valores.put("precio", s.getPrecio());
		simpleInsert.execute(valores);
		
	}

	@Override
	public List<Servicio> obtenerServicio() {
		String sql = ConstanteSQL.SQL_SELECCION_SERVICIOS;
		List<Servicio> servicios = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Servicio.class));
		return servicios;
	}


	public final void setElDataSource(DataSource elDataSource) {
		this.elDataSource = elDataSource;
		simpleInsert = new SimpleJdbcInsert(elDataSource);
		simpleInsert.setTableName("tabla_servicios");
		jdbcTemplate = new JdbcTemplate(elDataSource);
	}
	
	public final DataSource getElDataSource() {
		return elDataSource;
	}
	
	
	
	

}
