package daos;

import java.util.List;

import modelo.CategoriaUsuario;

public interface CategoriasUsuariosDAO {
	
	List<CategoriaUsuario> obtenerCategorias();

}
