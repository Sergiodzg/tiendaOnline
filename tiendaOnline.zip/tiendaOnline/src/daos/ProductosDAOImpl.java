package daos;

import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstanteSQL;
import mappers.ProductosMapper;
import modelo.Producto;
import modelo.Usuario;

public class ProductosDAOImpl implements ProductosDAO{
	
	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;

	
	public final void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		simpleInsert = new SimpleJdbcInsert(dataSource);
		simpleInsert.setTableName("tabla_productos");
		simpleInsert.usingGeneratedKeyColumns("id");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public int registrarProducto(Producto p) {
		HashMap<String, Object> valores = new HashMap<String, Object>();
		//nombres que figuran en la base de datos
		valores.put("titulo", p.getTitulo());
		valores.put("precio", p.getPrecio());
		valores.put("autor", p.getAutor());
		valores.put("genero", p.getGenero());
		valores.put("pags", p.getPags());
		System.out.println(p.getIdCategoriaProducto());
		valores.put("idCategoriaProducto", p.getIdCategoriaProducto());
//		simpleInsert.execute(valores);
		int idGenerate = simpleInsert.executeAndReturnKey(valores).intValue();
		return idGenerate;
			
	}

	@Override
	public List<Producto> obtenerProducto() {
		String sql = ConstanteSQL.SQL_SELECCION_PRODUCTOS;
		List<Producto> productos = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Producto.class));
		return productos;
	}
	
	

	public final DataSource getDataSource() {
		return dataSource;
	}

	@Override
	public void borrarProductoPorId(int id) {
		
		jdbcTemplate.update(ConstanteSQL.SQL_BORRAR_PRODUCTO,id);
		
	}

	@Override
	public Producto obtenerProductoPorId(int id) {
		
		String valores[] = {String.valueOf(id)};
		Producto producto = (Producto) jdbcTemplate.queryForObject(ConstanteSQL.SQL_OBTENER_PRODUCTO_POR_ID,valores,new BeanPropertyRowMapper(Producto.class));
		return producto;
		
	}

	@Override
	public void actualizarProducto(Producto p) {
		
		jdbcTemplate.update(ConstanteSQL.SQL_ACTUALIZAR_PRODUCTO,p.getTitulo(),p.getPrecio(),p.getAutor(),p.getGenero(),p.getPags(),p.getId());
		
	}

	@Override
	public List<Producto> obtenerProducto(int comienzo, int cuantos) {
		Integer[] valores = {Integer.valueOf(comienzo),Integer.valueOf(cuantos)};
		List<Producto> productos = jdbcTemplate.query(ConstanteSQL.SQL_SELECCION_PRODUCTOS_INICIO_CUANTOS,valores,new BeanPropertyRowMapper(Producto.class));
		return productos;
	}

	@Override
	public int obtenerTotalProductos() {
		int total = jdbcTemplate.queryForInt(ConstanteSQL.SQL_TOTAL_PRODUCTOS);
		return total;
	}

	@Override
	public List<Producto> obtenerProducto(int comienzo, int cuantos,
			String busqueda) {
		Object[] valores = {"%"+busqueda+"%", Integer.valueOf(comienzo),Integer.valueOf(cuantos)};

		List<Producto> productos = jdbcTemplate.query(ConstanteSQL.SQL_SELECCION_PRODUCTOS_CUANTOS_BUSQUEDA,valores,new ProductosMapper());
		return productos;
	}

	@Override
	public int obtenerTotalProductos(String busqueda) {
		int total = jdbcTemplate.queryForInt(ConstanteSQL.SQL_TOTAL_PRODUCTOS_BUSQUEDA,"%"+busqueda+"%");
		return total;
	}


}
