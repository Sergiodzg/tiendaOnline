package daos;

import java.util.ArrayList;
import java.util.List;

import modelo.Producto;
import modelo.Usuario;

public interface ProductosDAO {
	
	int registrarProducto(Producto p);
	List<Producto> obtenerProducto();
	void borrarProductoPorId(int id);
	Producto obtenerProductoPorId(int id);
	void actualizarProducto(Producto p);
	List<Producto> obtenerProducto(int comienzo, int cuantos);
	int obtenerTotalProductos();
	List<Producto> obtenerProducto(int comienzo, int cuantos, String busqueda);
	int obtenerTotalProductos(String busqueda);
	
}
