package daos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstanteSQL;
import modelo.Categoria;
import modelo.Producto;

public class CategoriasDAOImpl implements CategoriasDAO{
	
	private DataSource elDataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;

	@Override
	public void registrarCategoria(Categoria c) {
		
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", c.getNombre());
		valores.put("descripcion", c.getDescripcion());
		simpleInsert.execute(valores);
	}

	@Override
	public List<Categoria> obtenerCategoria() {
		
		String sql = ConstanteSQL.SQL_SELECCION_CATEGORIAS;
		List<Categoria> categoria = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Categoria.class));
		return categoria;
	}



	public void setElDataSource(DataSource elDataSource) {
		this.elDataSource = elDataSource;
		simpleInsert = new SimpleJdbcInsert(elDataSource);
		simpleInsert.setTableName("tabla_categorias");
		jdbcTemplate = new JdbcTemplate(elDataSource);
	}
	
	public DataSource getElDataSource() {
		return elDataSource;
	}
	

}
