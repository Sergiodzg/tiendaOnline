package daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import constantes.ConstanteSQL;
import modelo.CategoriaUsuario;

public class CategoriasUsuariosDAOImpl implements CategoriasUsuariosDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<CategoriaUsuario> obtenerCategorias() {

		List<CategoriaUsuario> categoriasUsuarios = jdbcTemplate.query(ConstanteSQL.SQL_SELECCION_USUARIOS_CATEGORIAS, new BeanPropertyRowMapper(CategoriaUsuario.class));
		return categoriasUsuarios;
	}

	public final void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
}
