package daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import constantes.ConstanteSQL;
import modelo.CategoriaProducto;
import modelo.CategoriaUsuario;

public class CategoriasPoductosDAOImpl implements CategoriasPoductosDAO{
	

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	

	@Override
	public List<CategoriaProducto> obtenerCategorias() {
		
		List<CategoriaProducto> categoriasProductos = jdbcTemplate.query(ConstanteSQL.SQL_SELECCION_PRODUCTOS_CATEGORIAS, new BeanPropertyRowMapper(CategoriaProducto.class));
		return categoriasProductos;
		
	}
	
	public final void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

}
