package daos;

import java.util.List;

import modelo.CategoriaProducto;

public interface CategoriasPoductosDAO {
	
	List<CategoriaProducto> obtenerCategorias();

}
