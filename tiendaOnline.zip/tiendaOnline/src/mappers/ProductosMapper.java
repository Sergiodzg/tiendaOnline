package mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import modelo.CategoriaProducto;
import modelo.Producto;

public class ProductosMapper implements RowMapper<Producto>{

	@Override
	public Producto mapRow(ResultSet rs, int numeroFila) throws SQLException {
		
		Producto p = new Producto();
		p.setTitulo(rs.getString("titulo"));
		p.setPrecio(rs.getDouble("precio"));
		p.setAutor(rs.getString("autor"));
		p.setGenero(rs.getString("genero"));
		p.setPags(rs.getInt("pags"));
		p.setId(rs.getInt("id"));
		CategoriaProducto cp = new CategoriaProducto();
		cp.setNombre(rs.getString("nombre_categoria"));
		p.setCategoriaProducto(cp);
		
		return p;
	}

}
